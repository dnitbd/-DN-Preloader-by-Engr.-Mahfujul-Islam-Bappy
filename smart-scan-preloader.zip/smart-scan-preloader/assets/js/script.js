document.addEventListener("DOMContentLoaded", function() {
    const preloader = document.getElementById('smart-scan-preloader');
    const percentageText = document.getElementById('preloader-percentage');
    let currentPercent = 0;
    let pageLoaded = false;
    window.addEventListener('load', () => { pageLoaded = true; });
    const counterInterval = setInterval(() => {
        if (currentPercent < 100) {
            if (currentPercent === 99 && !pageLoaded) return;
            currentPercent++;
            percentageText.textContent = currentPercent + '%';
        }
        if (currentPercent >= 100 && pageLoaded) {
            clearInterval(counterInterval);
            setTimeout(() => {
                preloader.classList.add('preloader-hidden');
                setTimeout(() => { if (preloader) preloader.style.display = 'none'; }, 900);
            }, 300);
        }
    }, 40);
});