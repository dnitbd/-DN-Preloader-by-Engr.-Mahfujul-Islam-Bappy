<?php
/**
 * Plugin Name:       Preloader by Engr. Mahfujul Islam Bappy
 * Plugin URI:        https://github.com/dnitbd/-DN-Preloader-by-Engr.-Mahfujul-Islam-Bappy
 * Description:       Adds a beautiful, mobile scanning-style animated preloader to any WordPress site.
 * Version:           64.41.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            DreamNest IT Park
 * Author URI:        https://www.dnit.com/resources/smart-scan-preloader.html
 * License:           GPL v3 or later
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       dn-preloader-bappy
 */

// Exit if accessed directly for security.
if ( ! defined( 'ABSPATH' ) ) {
    die;
}

/**
 * Enqueues the CSS and JavaScript files for the preloader.
 */
function ssp_bappy_enqueue_assets() {
    // Enqueue the stylesheet.
    wp_enqueue_style(
        'ssp-bappy-style',
        plugin_dir_url( __FILE__ ) . 'assets/css/style.css',
        [],
        '64.41.1' // Match your plugin version
    );

    // Enqueue the JavaScript file and load it in the footer.
    wp_enqueue_script(
        'ssp-bappy-script',
        plugin_dir_url( __FILE__ ) . 'assets/js/script.js',
        [],
        '64.41.1', // Match your plugin version
        true // Load in footer
    );
}
add_action( 'wp_enqueue_scripts', 'ssp_bappy_enqueue_assets' );

/**
 * Adds the preloader HTML right after the opening <body> tag.
 */
function ssp_bappy_add_preloader_html() {
    echo '<!-- Preloader by Engr. Mahfujul Islam Bappy --><div id="smart-scan-preloader"><div class="preloader-content"><div class="phone-container"><div class="scan-line"></div><svg class="phone-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 200"><path d="M85,200 C93.2842712,200 100,193.284271 100,185 L100,15 C100,6.71572875 93.2842712,0 85,0 L15,0 C6.71572875,0 0,6.71572875 0,15 L0,185 C0,193.284271 6.71572875,200 15,200 L85,200 Z M50,182 C45.581722,182 42,178.418278 42,174 C42,169.581722 45.581722,166 50,166 C54.418278,166 58,169.581722 58,174 C58,178.418278 54.418278,182 50,182 Z M70,12 L30,12 C27.2385763,12 25,9.76142375 25,7 C25,4.23857625 27.2385763,2 30,2 L70,2 C72.7614237,2 75,4.23857625 75,7 C75,9.76142375 72.7614237,12 70,12 Z"></path></svg><div class="star star1"></div><div class="star star2"></div><div class="star star3"></div></div><div id="preloader-percentage" class="preloader-text">0%</div><div class="preloader-text scanning-text">Scanning device</div></div></div><!-- End Preloader -->';
}
add_action( 'wp_body_open', 'ssp_bappy_add_preloader_html' );